﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Mapper.Abstrat;
using Mapper.Concret;

namespace Mapper
{
    public class Builder
    {
        public string connectionString;
        public string typeOfMapping;
        string[] propertiesArray = new string[] { null, null, null, null, null, null };


        public Builder(string connectionString, string mapType) 
        {
            this.connectionString = connectionString;
            this.typeOfMapping = mapType;
        }

        public IDataMapper<T> Build<T>() where T:class
        {
            Type tp = typeof(T);
            PropertyInfo[] properties = tp.GetProperties();
            int count = 0;
            TableAttribute at = (TableAttribute)tp.GetCustomAttribute(typeof(TableAttribute), false);
            string tabelaName = at.Name;

            foreach (PropertyInfo p in properties)
            {
                if (p.IsDefined(typeof(ColumnAttribute), false))
                {
                    propertiesArray[count++] = p.Name;
                }
            }

            return new EDSharedForAll<T>(connectionString,++count, propertiesArray, tp,tabelaName, properties,at);
        }

    }
}
