﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Linq.Mapping;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Mapper.Abstrat;

namespace Mapper.Concret
{
    public class EDSharedForAll<T> : IDataMapper<T>
    {
        string conectionString;
        string select;
        string tabela;
        string[] propertiesArray;
        PropertyInfo[] prop;
        TableAttribute at;
        Type type;
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        int pk;
        string pkName;

        private int MAX_COLUN;

        public EDSharedForAll(string conectionString, int count, string[] propertiesArray, Type type, string tabela, PropertyInfo[] prop, TableAttribute at) 
        {
            this.conectionString = conectionString;
            this.propertiesArray = propertiesArray;
            this.type = type;
            this.tabela = tabela;
            MAX_COLUN = count;
            this.prop = prop;
            this.at = at;
        }

        #region IDataMapper<T> Members

        public IEnumerable<T> GetAll()
        {
            using(con=new SqlConnection(conectionString))
            {
            
                cmd = con.CreateCommand();
                cmd.CommandText = selectComandTest(); 
                con.Open();
                dr = cmd.ExecuteReader();
                T objectToReturn;
                PropertyInfo[] property;
                object[] values = new object[MAX_COLUN];
                int idx = 0;

                while (dr.Read()) 
                {
                    for(int i=0; i< MAX_COLUN;++i)
                    {
                        values[i] = dr.GetValue(i);
                        
                    }
                    
                    objectToReturn= Activator.CreateInstance<T>();
                  
                    property = objectToReturn.GetType().GetProperties();

                    foreach (PropertyInfo p in property)
                    {
                        foreach (string propArray in propertiesArray)
                        {
                            if (p.Name.Equals(propArray) && p.IsDefined(typeof(ColumnAttribute),false))
                            {
                                p.SetValue(objectToReturn, values[idx]);
                                break;
                            }
                            ++idx;
                        }

                        idx = 0;
                    }
                    yield return  objectToReturn;
                }

                dr.Close();
            }
        }

        public void Update(T val)
        {
            /*
             * UPDATE tablename SET column1=value1, column2=value2, ...* WHERE columnID=n
             */
            using (con = new SqlConnection(conectionString))
            {
                cmd = con.CreateCommand();
                string comandText = updateComandTest(val);
                cmd.CommandText = comandText;
                con.Open();
                cmd.ExecuteNonQuery();
            }
            con.Close();
        }

        public void Delete(T val)
        {
            /* 
             * DELETE FROM titles WHERE titleID=8
             */
            using (con = new SqlConnection(conectionString))
            {
                cmd = con.CreateCommand();
                string comandText = deleteComandTest(val);// TO DO
                cmd.CommandText = comandText;
                con.Open();
                cmd.ExecuteNonQuery();
            }
            con.Close();
        }

        public void Insert(T val)
        {
            using (con = new SqlConnection(conectionString))
            {
                cmd = con.CreateCommand();
                string comandText = insertCommandTest(val);
                cmd.CommandText = comandText;
                con.Open();
                cmd.ExecuteNonQuery();
            }
            con.Close();
        }

        private string deleteComandTest(T val)
        {
            /* DELETE FROM titles WHERE titleID=8 */
            string comandText = "DELETE FROM " + tabela + " WHERE ";
            PropertyInfo[] propert = val.GetType().GetProperties();
            ColumnAttribute col; //= (ColumnAttribute)p.GetCustomAttribute(val.GetType());

            foreach (PropertyInfo p in propert)
            {
                col = (ColumnAttribute)p.GetCustomAttribute(typeof(ColumnAttribute));
                if (col != null && col.IsDbGenerated && col.IsPrimaryKey)
                {
                    pk = (int)p.GetValue(val);
                    pkName = p.Name;
                    break;
                }

            }

            return comandText += pkName + " = " + pk;
        }

        private string updateComandTest(T val) 
        {
            /*
             * UPDATE tablename SET column1=value1, column2=value2, ...* WHERE columnID=n
             */
            string comandText = "UPDATE "+ tabela+ " SET ";
            string colunas = "";
            PropertyInfo[] propert = val.GetType().GetProperties();
            ColumnAttribute col; //= (ColumnAttribute)p.GetCustomAttribute(val.GetType());
           
            foreach(PropertyInfo p in propert)
            {
                col = (ColumnAttribute)p.GetCustomAttribute(typeof(ColumnAttribute));
                if ( col!=null && col.IsDbGenerated ) 
                {
                    pk =(int)p.GetValue(val);
                    pkName = p.Name;
                    continue;
                }
                foreach(string propArray in propertiesArray)
                {
                    if(p.Name.Equals(propArray) && p.IsDefined(typeof(ColumnAttribute),false))
                    {
                        colunas += p.Name + "=";
                        if (p.GetValue(val)==null)
                        {
                            colunas+="null"+",";
                            break;
                        }
                        else
                        colunas +=p.GetValue(val) +",";
                        break;
                    }
                }
            }
            colunas = colunas.Substring(0, colunas.Length - 1);
                return comandText += colunas + " WHERE "+ pkName+ " = "+ pk;
        }

        private string insertCommandTest(T val) 
        {
            /*
             * INSERT INTO categories (catName, parentCatID, hierNr, hierIndent) VALUES ('Operating systems', 1, 7, 2)
             */
            string comandText = "INSERT INTO " + tabela;
            string values="";
            string colunas="";
            ColumnAttribute col;

            foreach (PropertyInfo p in prop)
            {
                col = (ColumnAttribute)p.GetCustomAttribute(typeof(ColumnAttribute));
                if (col != null && col.IsDbGenerated) continue;
             

                foreach (string propArray in propertiesArray)
                {

                    if (p.Name.Equals(propArray) && p.IsDefined(typeof(ColumnAttribute), false))
                    {
                        if (p.GetValue(val) == null) 
                        {
                            values += "null " + ",";
                            colunas += p.Name + ",";
                            break; 
                        }

                        Type t = p.GetValue(val).GetType() ;
                        Type t1 = typeof(string);

                        if (t.Equals(t1)) 
                        {
                            values +="'"+p.GetValue(val)+"'" + ",";
                            colunas += p.Name + ",";
                            break;
                        }
                        values += p.GetValue(val) + ",";
                        colunas += p.Name + ",";
                        break;
                    }
                }
            }
            values = values.Substring(0, values.Length - 1);
            colunas = colunas.Substring(0, colunas.Length - 1);
            comandText +=" ("+ colunas + ") VALUES ("+ values+" )";

            return comandText;
        }

        private string selectComandTest() 
        {
            string Coluna = "";
            string select;
            foreach (PropertyInfo p in prop)
            {
               
                if (p.IsDefined(typeof(ColumnAttribute), false))
                {
                    Coluna = Coluna + p.Name + ",";
                }
            }

            Coluna = Coluna.Substring(0, Coluna.Length - 2);
            return select = "SELECT " + Coluna + " FROM " + tabela;
        }
        #endregion
    }
}
