﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mapper.Anotacoes
{
    [AttributeUsage(AttributeTargets.Property)]
    public class PropertyAttribute: System.Attribute
    {
        string propertyName;

        public PropertyAttribute(string propertyName) 
        {
            this.propertyName = propertyName;
        }
    }
}
