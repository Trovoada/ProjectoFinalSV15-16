﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mapper.Anotacoes;
using System.Data.Linq.Mapping;

namespace Mapper
{
    [Table(Name = "Product")]
    public class EDProduct
    {
        [Column(Name = "ProductID", IsPrimaryKey = true, IsDbGenerated = true)]
        public int ProductID { set; get; }

        [Column(Name = "ProductName")]
        public string ProductName { set; get; }

        [Column(Name = "QuantityPerUnit")]
        public string QuantityPerUnit { set; get; }

       
        public decimal UnitPrice { set; get; }

        [Column(Name = "UnitsInStock")]
        public short UnitsInStock { set; get; }

        [Column(Name = "UnitsOnOrder")]
        public short UnitsOnOrder { set; get; }
    }
}
