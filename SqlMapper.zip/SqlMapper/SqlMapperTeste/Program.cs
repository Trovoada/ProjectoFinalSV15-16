﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Mapper;
using Mapper.Abstrat;




namespace SqlMapperTeste
{
    class Program
    {
        static void Main(string[] args)
        {
            Type tp = typeof(EDProduct);
            PropertyInfo[] propert = tp.GetProperties();
            string conect= @"Data Source=HILTON-PC\SQLEXPRESS; Initial Catalog=Ave; Integrated Security=True";

            EDProduct val = new EDProduct() { ProductName = "chuteiras", QuantityPerUnit = "2", UnitPrice = 20, UnitsInStock = 50, UnitsOnOrder = 3 };
            EDProduct val1 = new EDProduct() { ProductID=1, ProductName="chuteiras", QuantityPerUnit="2", UnitPrice=20, UnitsInStock=50, UnitsOnOrder=3 };


            Builder b = new Builder(conect, " ");
            IDataMapper<EDProduct> prodMapper = b.Build<EDProduct>();
            prodMapper.Insert(val);
            prodMapper.Delete(val1);
            IEnumerable<EDProduct> prods = prodMapper.GetAll();
        }
    }
}
