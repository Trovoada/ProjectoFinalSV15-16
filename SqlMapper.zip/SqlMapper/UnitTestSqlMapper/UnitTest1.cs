﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestSqlMapper
{
    [TestClass]
    public class UnitTest1
    {
        Builder b = new Builder(" ", " "); 
        IDataMapper<Product> prodMapper = b.Build<Product>(); 
        IEnumerable<Product> prods = prodMapper.GetAll();
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
